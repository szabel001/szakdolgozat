import os
import ast  #for file reading
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit